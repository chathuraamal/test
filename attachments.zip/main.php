<?php

class Main extends CI_Model {

    public function addData($tablename, $data_arr) {
        $a = $this->db->insert($tablename, $data_arr);
        return $a;
    }

}

?>